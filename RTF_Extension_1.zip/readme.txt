----------------[Информация]---------------------
Целью данного проекта является перевод модов и другого контента на русский язык.
Вы можете использовать этот пакет ресурсов для любых целей, но приветствуется ссылка на первоисточник.
Единственное, о чем я хотел бы попросить, это то, что если вы собираетесь добавить или обновить перевод из этого пакета ресурсов, присоединяйтесь к нашему сообществу.
Я хочу, чтобы люди скачали 1-2 русификатора для комфортного геймплея, не более. Любая помощь и предоставление готовых переводов приветствуются.
Этот пакет ресурсов является дополнением к уже замороженному RTF.

https://modrinth.com/resourcepack/rtf

Использовать его отдельно от RTF нет смысла, так как большая часть переводов взята оттуда.
Искренне надеюсь, что автор оригинального RTF поменяет лицензию на более свободную или вернется к переводам, в этом случае я постараюсь договориться об объединении русификаторов для всеобщего удобства

----------------[Information]---------------------
This project aims to translate mods and other content into Russian.
You can use this resource pack for any purpose, but credit to the original source is appreciated.
The only thing I would ask is that if you are going to add or update a translation from this resource pack, please join our community.
I want people to download 1-2 cracks for comfortable gameplay, no more. Any help and provision of ready-made translations are welcome
This resource pack is an addition to the now frozen RTF
https://modrinth.com/resourcepack/rtf

It makes no sense to use it separately from RTF since most of the translations are taken from there.
I sincerely hope that the author of the original RTF will change the license to a freer one or return to translations, in which case I will try to agree on merging Russifiers for everyone’s convenience